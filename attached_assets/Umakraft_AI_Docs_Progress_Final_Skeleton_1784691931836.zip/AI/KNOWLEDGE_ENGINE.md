# KNOWLEDGE_ENGINE

Defines repository knowledge scope, Umamusume knowledge scope, source priority, confidence scoring, citation rules, repository synchronization, read-only knowledge lifecycle, FAQ engine, glossary, semantic retrieval, and off-topic rejection.
