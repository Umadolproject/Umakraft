# AI ARCHITECTURE

**Authority:** `GOVERNANCE/ARCHITECTURE_AUTHORITY.md`  
**Registry:** `GOVERNANCE/PIPELINE_REGISTRY.md`  
**Department:** Knowledge  
**Status:** ACTIVE  
**Version:** 1.0.0  
**Last Updated:** 2026-07-22

---

# Directory Tree

```text
AI/
├── README.md
├── IMPLEMENTATION_PLAN.md
├── ARCHITECTURE.md
├── REPOSITORY_ENGINE.md
├── KNOWLEDGE_ENGINE.md
├── MESSAGE_SYSTEM.md
├── PROMPT_SYSTEM.md
├── API_PROVIDER.md
├── SECURITY.md
├── RAG_ENGINE.md
├── VECTOR_DATABASE.md
├── REPOSITORY_INDEXER.md
├── CONTENT_GENERATOR.md
├── TOPIC_FILTER.md
├── CONTEXT_BUILDER.md
├── RESPONSE_VALIDATOR.md
├── CACHE.md
├── CONFIGURATION.md
├── TESTING.md
├── ROADMAP.md
└── EXAMPLES.md
```

---

# Purpose

This document defines the complete architecture of the Umakraft AI Knowledge Service.

The service is designed as a **read-only intelligence layer** that understands the repository, explains Umamusume mechanics, and generates community content without having the ability to modify code, configuration, databases, or Discord operations.

---

# Core Principle

**Read Everything. Change Nothing.**

The AI may:

- Read repository files
- Read source code
- Read documentation
- Read blueprints
- Read governance files
- Read templates
- Read configuration documentation

The AI may **never**:

- Modify files
- Delete files
- Create commits
- Push to GitHub
- Execute shell commands
- Write to databases
- Change Discord settings
- Access secrets or tokens

---

# High-Level Architecture

```mermaid
flowchart TD
    A[Discord User] --> B[AI Command Gateway]
    B --> C[Topic Filter]

    C -->|Repository| D[Repository Search]
    C -->|Umamusume| E[Knowledge Engine]
    C -->|Message| F[Content Generator]
    C -->|Off Topic| G[Reject]

    D --> H[Context Builder]
    E --> H
    F --> H

    H --> I[Prompt Builder]
    I --> J[AI Provider]

    J --> K[Response Validator]
    K --> L[Discord Response]
```

---

# Service Layers

## Presentation Layer

### AI Command Gateway

Responsible for receiving Discord interactions.

Supported commands:

```text
/ask
/ai explain
/ai search
/ai docs
/ai glossary
/ai message
```

Responsibilities:

- Parse command
- Validate user input
- Apply rate limits
- Forward request to the correct service

---

## Intelligence Layer

### Topic Filter

Determines whether a request is:

- Repository-related
- Umamusume-related
- Message-generation-related
- Off-topic

Example:

| User Question | Result |
|---|---|
| Explain fan gain | Repository |
| What is MANT | Umamusume |
| Generate morning greeting | Message |
| Who is the president | Rejected |

---

## Repository Intelligence Layer

### Repository Search

Performs semantic retrieval across:

- README files
- Blueprints
- Governance documents
- Command documentation
- Service documentation
- TypeScript source code
- Configuration references

Search strategy:

1. Embed query
2. Search vector database
3. Retrieve top N chunks
4. Rank by relevance
5. Send to Context Builder

---

# Repository Chunk Model

```ts
export interface RepositoryChunk {
    id: string;
    path: string;
    title: string;
    section: string;
    content: string;
    embedding: number[];
    updatedAt: string;
}
```

---

# Knowledge Engine

Contains curated Umamusume knowledge.

Modules:

```text
KnowledgeEngine/
├── FanGain
├── Training
├── CareerModes
├── Legacy
├── Races
├── Skills
├── Events
├── CircleSystem
└── RankingSystem
```

Example capability:

- Explain MANT
- Explain UAF
- Explain fan farming
- Explain legacy inheritance
- Explain race scheduling

---

# Content Generator

Generates community messages.

Supported blocks:

```text
Greeting
Milestone
Achievement
DailyLeaderboard
WeeklyLeaderboard
MonthlyLeaderboard
Warning
Recovery
Welcome
Farewell
Maintenance
Event
Announcement
Motivation
PatchNotes
```

All outputs must be **100-150 words**.

---

# Context Builder

Combines information from multiple sources.

Input:

- Repository chunks
- Umamusume knowledge
- Message variables
- Conversation context

Output:

```ts
export interface AIContext {
    query: string;
    repositoryChunks: RepositoryChunk[];
    knowledgeEntries: KnowledgeEntry[];
    messageVariables?: Record<string, string>;
    conversationHistory: ConversationEntry[];
}
```

---

# Prompt Builder

Constructs the final AI prompt.

System Prompt:

```text
You are the Umakraft Knowledge Assistant.

You may answer only:
- Repository questions
- Umamusume questions
- Community message requests

You must reject all unrelated topics.

You have read-only access to the repository.
You cannot modify files, execute code, or perform administrative actions.
```

---

# AI Provider Layer

The architecture is provider-agnostic.

```mermaid
flowchart LR
    A[Prompt Builder] --> B[Provider Manager]
    B --> C[OpenAI]
    B --> D[Gemini]
    B --> E[Claude]
    B --> F[OpenRouter]
    B --> G[Ollama]
```

---

# Provider Interface

```ts
export interface AIProvider {
    initialize(): Promise<void>;

    generate(
        request: AIRequest
    ): Promise<AIResponse>;

    healthCheck(): Promise<boolean>;
}
```

This allows switching providers without changing business logic.

---

# Response Validator

Validates every AI output before sending it to Discord.

Checks:

- Topic compliance
- Repository-only rule
- Umamusume-only rule
- Word count (100-150 for messages)
- No fabricated repository data
- No secret leakage
- No unsupported markdown

---

# Message Validation

```ts
export interface ValidationResult {
    valid: boolean;
    reason?: string;
    wordCount?: number;
    violations: string[];
}
```

---

# Security Architecture

## Permission Guard

```mermaid
flowchart TD
    A[AI Request] --> B[Permission Guard]
    B -->|Read| C[Allowed]
    B -->|Write| D[Blocked]
    B -->|Execute| D
    B -->|Secrets| D
```

Blocked operations:

- fs.writeFile
- fs.unlink
- git push
- git commit
- database INSERT
- database UPDATE
- database DELETE
- shell execution

---

# Repository Access Model

## Allowed Paths

```text
README.md
GOVERNANCE/**
Blueprints/**
FanTracker/**
Discord/**
Broadcast/**
Templates/**
Documentation/**
```

## Restricted Paths

```text
.env
.env.*
secrets/**
tokens/**
keys/**
node_modules/**
.git/**
```

---

# RAG Pipeline

```mermaid
sequenceDiagram
    participant U as User
    participant G as Gateway
    participant S as Search
    participant C as Context
    participant P as Prompt
    participant AI as Provider
    participant V as Validator

    U->>G: /ask How is fan gain calculated?
    G->>S: semantic search
    S-->>C: relevant chunks
    C->>P: assembled context
    P->>AI: final prompt
    AI-->>V: response
    V-->>U: validated answer
```

---

# Repository Indexing Flow

```mermaid
flowchart TD
    A[Repository] --> B[File Scanner]
    B --> C[Markdown Parser]
    B --> D[Code Parser]

    C --> E[Chunker]
    D --> E

    E --> F[Embedding Generator]
    F --> G[Vector Database]
```

---

# Caching Architecture

## Cache Types

| Cache | Purpose |
|---|---|
| Query Cache | Repeated questions |
| Context Cache | Retrieved chunks |
| Embedding Cache | Reused embeddings |
| Message Cache | Frequently generated announcements |

---

# Metrics & Observability

Collected metrics:

```text
total_queries
repository_queries
umamusume_queries
message_queries
rejected_queries
average_latency
provider_errors
cache_hit_rate
validation_failures
```

---

# Error Handling

## Provider Failure

Fallback order:

```text
Primary Provider
    ↓
Secondary Provider
    ↓
Cached Response
    ↓
Friendly Error Message
```

Example response:

```text
The AI provider is temporarily unavailable. Please try again in a few moments.
```

---

# Scalability

The architecture supports:

- Multiple Discord servers
- Multiple repositories
- Additional game knowledge modules
- New message categories
- Future web dashboard integration
- Analytics dashboards
- Citation mode
- Confidence scoring

---

# Future Extension Points

## Plugin System

```text
Plugins/
├── RepositoryStats
├── BlueprintValidator
├── DocumentationQA
├── Localization
├── Analytics
└── HallOfFame
```

## Conversation Memory

Short-term memory for a single session.

## Citation Mode

Example:

```text
Source:
- FanTracker/Calculation/FanGain.ts
- Documentation/FanGain.md
```

## Confidence Score

Example:

```text
Confidence: 94%
Source Type: Repository Documentation
```

---

# Architectural Guarantees

The AI subsystem guarantees:

- **Read-only repository access**
- **No code modification capability**
- **Repository-scoped responses**
- **Umamusume-scoped responses**
- **Automatic off-topic rejection**
- **Validated message generation**
- **Provider abstraction**
- **Secure context handling**
- **Scalable retrieval architecture**
- **Auditable response pipeline**

These guarantees form the foundation of the Umakraft AI Knowledge Service and must remain unchanged across all future versions of the architecture.
