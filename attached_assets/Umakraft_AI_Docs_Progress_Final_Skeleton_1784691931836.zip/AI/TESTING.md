# TESTING

Defines unit tests, integration tests, repository search tests, prompt tests, message generation tests, regression tests and acceptance criteria.
