# REPOSITORY_ENGINE.md

Version: 1.0.0

# Purpose

The Repository Engine is responsible for giving the AI read-only understanding of the Umakraft repository.

## Responsibilities

- Scan repository
- Read Markdown
- Read source code
- Read governance documents
- Read blueprints
- Read configuration documentation
- Build searchable knowledge
- Never modify repository contents

# Directory Coverage

```text
/
├── GOVERNANCE/
├── Operation/
├── FanTracker/
├── Broadcast/
├── Distribution/
├── Commands/
├── Messages/
├── Templates/
├── Database/
├── Assets/
└── README.md
```

# Pipeline

Repository
↓
Scanner
↓
Document Classifier
↓
Parser
↓
Chunk Builder
↓
Embedding Queue
↓
Vector Database
↓
Semantic Search

# Document Types

- README
- Markdown
- TypeScript
- JavaScript
- JSON
- YAML
- SQL
- Text

# Chunk Strategy

Target chunk size:
- 500-1200 characters

Metadata:
- file path
- heading
- department
- last indexed
- checksum

# Repository Rules

Allowed:
- Read all project files
- Cross-reference documents
- Explain code
- Explain architecture

Forbidden:
- Edit files
- Delete files
- Rename files
- Execute scripts
- Commit changes

# Search Modes

1. Exact filename
2. Semantic search
3. Blueprint search
4. Governance search
5. Command search
6. Folder search

# Source Citation

Each answer should retain:
- File name
- Section title
- Confidence level

# Future

- Incremental indexing
- Git diff awareness
- Broken link detection
- Duplicate document detection
- Repository health report
