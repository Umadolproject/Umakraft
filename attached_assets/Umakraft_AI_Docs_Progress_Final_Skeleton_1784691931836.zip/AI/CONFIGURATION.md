# CONFIGURATION

Documents environment variables, API configuration, model selection, embedding provider, cache settings, logging, rate limits and feature flags.
