# TOPIC_FILTER

Defines repository-only and Umamusume-only scope. Rejects politics, finance, medical, unrelated coding and general trivia. Includes keyword filters, semantic classifier, override rules and audit logging.
