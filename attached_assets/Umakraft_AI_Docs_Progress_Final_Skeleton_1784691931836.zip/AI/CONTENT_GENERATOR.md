# CONTENT_GENERATOR

Defines AI generation pipeline for greetings, milestones, achievements, rankings, announcements, reminders and custom messages. Includes validation (100–150 words), style profiles, variable injection, copy-ready message blocks and duplicate prevention.
