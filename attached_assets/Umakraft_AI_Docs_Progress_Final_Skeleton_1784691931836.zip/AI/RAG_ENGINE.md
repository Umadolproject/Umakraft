# RAG_ENGINE

Defines retrieval-augmented generation pipeline: repository indexing, chunk retrieval, embedding search, context assembly, prompt creation, LLM response, validation, and citation. Includes chunking strategy, token budget, cache, confidence scoring, and failure handling.
