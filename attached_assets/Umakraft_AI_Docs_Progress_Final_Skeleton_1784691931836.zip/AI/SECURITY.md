# SECURITY

Read-only enforcement, permission matrix, secret protection, API key handling, repository isolation, audit logging, topic filtering, and prohibited operations.
