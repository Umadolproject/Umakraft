# MESSAGE_SYSTEM

Documents Message Blocks, 100-150 word validation, greeting, milestone, achievement, daily/weekly/monthly leaderboard, warning, reminder, maintenance, welcome, farewell, prompt templates, variable injection, duplicate prevention and copy-ready output.
