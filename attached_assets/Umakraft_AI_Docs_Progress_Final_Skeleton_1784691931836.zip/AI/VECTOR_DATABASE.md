# VECTOR_DATABASE

Specifies vector storage, embedding schema, metadata, indexing frequency, similarity search, update policy, deletion policy, cache integration, backup and restore.
