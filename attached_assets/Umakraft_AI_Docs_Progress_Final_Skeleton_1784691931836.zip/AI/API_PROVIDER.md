# API_PROVIDER

Abstract provider layer supporting OpenAI, Gemini, Claude, OpenRouter and Ollama. Covers configuration, retries, rate limits, model selection and fallback strategy.
