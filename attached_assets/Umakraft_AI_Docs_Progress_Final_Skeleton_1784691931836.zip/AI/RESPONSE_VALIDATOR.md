# RESPONSE_VALIDATOR

Validates repository scope, grammar, message length, prohibited topics, hallucination checks, citation availability, confidence threshold and output formatting.
