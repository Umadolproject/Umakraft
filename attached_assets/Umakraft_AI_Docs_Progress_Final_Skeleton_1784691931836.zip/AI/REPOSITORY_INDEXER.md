# REPOSITORY_INDEXER

Explains full and incremental indexing, supported file types, exclusion rules, checksum tracking, metadata extraction, heading parsing, and scheduling.
