# PROMPT_SYSTEM

Defines system prompts, repository prompts, message prompts, safety prompts, prompt composition, context injection, prompt versioning and examples.
