# CONTEXT_BUILDER

Assembles repository search results, removes duplicates, applies token budget, prioritizes governance, blueprints, code comments and documentation before building the final prompt.
