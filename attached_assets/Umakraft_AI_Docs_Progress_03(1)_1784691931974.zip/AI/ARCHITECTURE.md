# ARCHITECTURE.md

Version: 1.0.0

# AI Knowledge Service Architecture

## Purpose

The AI Knowledge Service is a read-only subsystem responsible for:
- Repository Q&A
- Umamusume Q&A
- Content generation
- Documentation assistance

The service never modifies repository data.

# High Level Architecture

```text
Discord User
    │
    ▼
Knowledge Command
    │
    ▼
Topic Filter
    │
    ├── Reject Off Topic
    │
    ▼
Repository Search
    │
    ▼
Context Builder
    │
    ▼
Prompt Builder
    │
    ▼
AI Provider
    │
    ▼
Response Validator
    │
    ▼
Discord
```

# Core Services

## AIManager

Responsibilities:

- Request orchestration
- Provider selection
- Error handling
- Retry management

## Repository Engine

Responsibilities:

- Read repository
- Parse markdown
- Parse governance files
- Parse blueprints
- Parse documentation

## Knowledge Engine

Responsibilities:

- Umamusume knowledge
- Repository knowledge
- FAQ knowledge

## Content Generator

Responsibilities:

- Greeting generation
- Milestone generation
- Achievement generation
- Leaderboard generation

# Read Only Model

Allowed:

- Read files
- Read markdown
- Read code
- Read blueprints

Forbidden:

- Edit files
- Delete files
- Push commits
- Merge PRs
- Execute repository changes

# Repository Flow

```text
Repository
    │
    ▼
Indexer
    │
    ▼
Chunk Builder
    │
    ▼
Embedding Engine
    │
    ▼
Vector Database
```

# Request Lifecycle

1. User submits question.
2. Topic Filter validates scope.
3. Repository Search retrieves context.
4. Context Builder assembles sources.
5. Prompt Builder creates prompt.
6. AI Provider generates answer.
7. Response Validator checks output.
8. Response sent to Discord.

# Supported Question Types

- Fan Gain
- Milestones
- Achievements
- Warnings
- Quotas
- Commands
- Pipelines
- Blueprints
- Architecture
- Umamusume systems

# Rejected Topics

- Politics
- Religion
- Medical advice
- Financial advice
- General trivia

# Future Architecture

- Multi provider routing
- Confidence scoring
- Source citation
- Localization
- Plugin support
